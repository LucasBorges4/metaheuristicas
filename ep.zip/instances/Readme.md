# Formato dos arquivos

  - Linha 1: número de ingredientes n, número de ingredientes incompatíveis |I|, peso máximo W
  - Linha em branco
  - Os próximos n números: sabores t1, t2, ..., tn
  - Linha em branco
  - Os próximos n números: pesos w1, w2, ..., wn
  - Linha em branco
  - Os próximos |I| linhas: números j k, para cada para j k de ingredientes incompatíveis
